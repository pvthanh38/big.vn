import express from 'express';
import bodyParser from 'body-parser';
import index from './routes/index';
import tag from './routes/tag';
import mongoose from 'mongoose';
import path from 'path';
let app = express();

app.set('views', 'views');
app.set('view engine', 'pug');
mongoose.Promise = global.Promise;

mongoose.connect('mongodb://localhost/test2018')
    .then(function () {})
    .catch(function (err) {
        console.error(err)
    });

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

let static_path = path.dirname(__dirname);

app.use('/assets', express.static(path.join(static_path, 'assets')));

app.use('/', index);
app.use('/tag', tag);

app.listen(3000, function () {
    console.log('Big app listening on port 3000!')
});