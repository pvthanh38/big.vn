const path = require('path');
export default {
    rootPath: ''
};