let unique = function (array) {
    return [...(new Set(array))];
};

export default unique;