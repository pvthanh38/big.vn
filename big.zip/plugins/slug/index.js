import slug from "slug";

export  default function(prop, required, opts){
  return (function slugize(schema){
    let required = required||false;
    let title;

    schema.add({ slug: {type: String, unique:true, required:required} });
    schema.pre('save', function(next){
      let self = this;

      if (prop && Array.isArray(prop)) {
        let titles = [];
        prop.forEach(function(el){
          titles.push(self[el]);
        });
        title = titles.join(' ');
      } else {
        title = this[prop || 'title'];
      }

      let require = (opts && !opts.required) ? false : true;
      if (require && !title) return next(new Error(prop + ' is required to create a slug'));
      if (title) self.slug = slug(title, opts).toLowerCase();
      next();
    });
  });
};
