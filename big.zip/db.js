var mongoose = require('mongoose');

var db = function () {
  this.state.db = null;
};


db.prototype.connect = function(url, done) {
    var mongoDB = 'mongodb://127.0.0.1/test2018';
    mongoose.connect(mongoDB, {
        useMongoClient: true
    });
    mongoose.Promise = global.Promise;
    var db = mongoose.connection;
    db.on('error', console.error.bind(console, 'MongoDB connection error:'));
};

db.prototype.get = function() {
    return this.state.db
};

db.prototype.close = function(done) {
    var self = this;
    if (this.state.db) {
        this.state.db.close(function(err, result) {
            self.state.db = null
            self.state.mode = null
            done(err)
        })
    }
};

module.exports = db;