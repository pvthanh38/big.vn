import express from 'express';
import Posts from './../models/Posts';
import Categories from './../models/Categories';
import mongoose from 'mongoose';
import async from 'async';
import slug from 'slug';

let router = express.Router();
router.get('/', function (req, res, next) {
    async.parallel({
        posts: function (cb) {
            Posts.find()
                .populate({path: 'categories', select: 'title slug'})
                .select('title excerpt categories slug')
                .exec(cb);
        },
        cats: function (cb) {
            Categories.find().exec(cb);
        }
    }, function (err, result) {
        res.render('index', {
            title: 'Big.vn',
            posts: result.posts ? result.posts : [],
            cats: result.cats
        });
    });

});

router.get('/page/:page', function (req, res, next) {
    async.parallel({
        posts: function (cb) {
            Posts.find()
                .skip(2)
                .populate({path: 'categories', select: 'title slug'})
                .select('title excerpt categories slug')
                .exec(cb);
        },
        cats: function (cb) {
            Categories.find().exec(cb);
        }
    }, function (err, result) {
        res.render('index', {
            title: 'Big.vn',
            posts: result.posts ? result.posts : [],
            cats: result.cats
        });
    });
});

router.get('/:slug.html', function (req, res, next) {
    const _slug = req.params.slug;
    async.parallel({
        post: function (next) {
            Posts
                .findOne({slug: _slug})
                .exec(next);
        },
        cats: function (next) {
            Categories.find().exec(next);
        },
        theCats: function (next) {
            Posts
                .findOne({slug: _slug})
                .populate(
                    {
                        path: 'categories',
                        model: 'Categories',
                        populate: {
                            path: 'posts',
                            model: 'Posts',
                            select: 'title slug featuredImage _id'
                        }
                    }
                )
                .exec(next);
        }
    }, function (err, result) {
        res.render('post', {
            title: 'Big.vn',
            theCats: result.theCats && result.theCats.categories ?  result.theCats.categories : [],
            post: result.post ? result.post : {},
            cats: result.cats
        });
    });
});

router.get('/:slug', function (req, res, next) {
    const slug = req.params.slug;
    async.parallel({
        posts: function (cb) {
            Categories.findOne({slug: slug})
                .populate('posts')
                .exec(cb);
        },
        cats: function (cb) {
            Categories.find().exec(cb);
        },
        cat: function (cb) {
            Categories.findOne({slug: req.params.slug}).exec(cb);
        }
    }, function (err, result) {
        res.render('archive', {
            title: 'Big.vn',
            posts: result.posts && result.posts.posts ? result.posts.posts : [],
            cats: result.cats,
            cat: result.cat,
        });
    });
});

router.post('/post', function (req, res, next) {
    let post = new Posts({
        _id: new mongoose.Types.ObjectId(),
        'title': 'Tóc đuôi lệch đẹp được nhiều sao Hàn ưa chuộng nhất 2017 năm nay ' + Date.now(),
        'excerpt': '<p><strong>Tóc đuôi lệch</strong> đẹp được nhiều sao Hàn ưa chuộng nhất 2017 năm nay là một trong những kiểu tóc đón đầu xu hướng thời trang tóc đẹp mà các bạn gái trẻ rất thích khám phá, thích trải nghiệm để biến hóa mình thành một nữ minh tinh thật dễ thương thật đáng yêu như sao. Cùng với sự lên ngôi của các kiểu tóc uốn xoăn, tóc dài suôn mượt, tóc nhuộm màu, tóc đánh ối,..thì style tóc đuôi lệch cũng khiến giới trẻ thích thú bởi nó làm toát lên khuôn mặt thật thanh tú của phái nữ, vừa cân đối nét mặt lại vừa quyến rũ đến khó cưỡng. Nhất là thả dáng trong những bộ váy quyền lực với mái tóc lệch đuôi thật ấn tượng, chắc chắn mọi ánh nhìn của chàng sẽ đổ dồn về phía bạn đó.</p>',
        'content': '<p>Nào hãy cùng Big.com tham khảo qua những mốt tóc đuôi lệch đẹp được nhiều sao Hàn ưa chuộng nhất 2017 năm nay bên dưới đây nhé!</p><table class="picture" align="center"><tbody><tr><td class="pic"><img class="aligncenter size-full wp-image-27 cool-image-share" src="https://big.vn/wp-content/uploads/2016/11/toc-duoi-lech-dep-duoc-nhieu-sao-han-ua-chuong-nhat-2017-nam-nay-1.jpg" alt="Tóc đuôi lệch đẹp được nhiều sao Hàn ưa chuộng nhất 2017 năm nay phần 1" width="500" height="708" srcset="https://big.vn/wp-content/uploads/2016/11/toc-duoi-lech-dep-duoc-nhieu-sao-han-ua-chuong-nhat-2017-nam-nay-1.jpg 500w, https://big.vn/wp-content/uploads/2016/11/toc-duoi-lech-dep-duoc-nhieu-sao-han-ua-chuong-nhat-2017-nam-nay-1-212x300.jpg 212w" sizes="(max-width: 500px) 100vw, 500px"></td></tr><tr></tr></tbody></table>'
    });

    post.save(function (err) {
        if (err) {
            res.send({status: err.message});
        }
        else {
            let title = "Mẹ & Bé";
            let _slug = slug(title).toLowerCase();

            let title2 = "Làm đẹp";
            let _slug2 = slug(title2).toLowerCase();


            async.parallel({
                set_1: (next) => Categories.setCategory({slug: _slug, title: title}, post, next),
                set_2: (next) => Categories.setCategory({slug: _slug2, title: title2}, post, next)
            }, (err, result) => {
                res.json({status: 'done'});
            });
        }
    });
});

export default router;