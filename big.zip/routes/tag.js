import express from 'express';
import Posts from './../models/Posts';

let router = express.Router();
router.get('/:slug', function (req, res, next) {
    res.render('index', {title: req.params.slug});
});

export default router;