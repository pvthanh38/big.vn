const mongoose = require('mongoose');
import slug from './../plugins/slug/index';
import unique from './../plugins/array/index';
import Posts from './Posts';
const Schema = mongoose.Schema;

const CategorySchema = new Schema({
    title: String,
    desc: String,
    featureImage: String,
    createdAt: Date,
    updatedAt: Date,
    posts: [{ type: Schema.Types.ObjectId, ref: 'Posts' }]
});

CategorySchema.plugin(slug('title', true));


class Category {
    static getCategoriesList(callback){
        return this.find(function (err, cats) {
            if (err) cats = [];
            if (typeof callback === 'function'){{
                callback(cats);
            }}
        });
    }

    static getCategoriesList2(){
        return this.find();
    }

    static setCategory(catFindOrCreate, post, callback = null){
        const self = this;
        this.findOne(catFindOrCreate, function (err, cat) {
            if (err || cat === null){
                self.create(catFindOrCreate, (err, result) => {
                    result.posts.push(post._id);
                    result.posts = unique(result.posts);

                    result.save(function () {
                        post.categories.push(result._id);
                        post.categories = unique(post.categories);
                        post.save(function(){
                            callback();
                        });
                    });
                });
            }
            else{
                cat.posts.push(post._id);
                cat.posts = unique(cat.posts);
                cat.save(function () {
                    post.categories.push(cat._id);
                    post.categories = unique(post.categories);
                    post.save(function () {
                        callback();
                    });
                });
            }
        });
    }
    static getPosts(slug, callback){
        this
            .findOne({slug: slug})
            .populate('posts')
            .exec(function (err, posts) {
                if (typeof callback === 'function'){
                    callback(posts);
                }
            });
    }
}

CategorySchema.loadClass(Category);

export default mongoose.model('Categories', CategorySchema);