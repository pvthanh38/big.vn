const mongoose = require('mongoose');
import mongoosePaginate from 'mongoose-paginate';

import slug from './../plugins/slug/index';
import Categories from './Categories';

const Schema = mongoose.Schema;

const PostSchema = new Schema({
    title: String,
    content: String,
    excerpt: String,
    featureImage: String,
    createdAt: Date,
    updatedAt: Date,
    author: Schema.Types.ObjectId,
    categories: [{ type: Schema.Types.ObjectId, ref: 'Categories' }]
});


class Post {
    static getCategories(slug, callback){
        this
            .findOne({slug: slug})
            .populate('categories')
            .exec(function (err, posts) {
                if (typeof callback === 'function'){
                    callback(posts);
                }
            });
    }
}

PostSchema.plugin(slug('title', true));
PostSchema.plugin(mongoosePaginate);
PostSchema.loadClass(Post);


PostSchema.pre('save', function(next){
    try{
        this.createdAt = Date.now();
        this.updatedAt = Date.now();
    }
    catch(e){
        console.log(e);
    }
    next();
});

export default mongoose.model('Posts', PostSchema, 'posts');